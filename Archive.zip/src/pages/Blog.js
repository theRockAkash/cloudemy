import PageBAnner from "../component/PageBanner"

const Blog = () =>{
    return (
        <>
            <PageBAnner bannerImg={"https://picsum.photos/id/20/3670/2462"} title="Blogs"/>
        </>
    )
}
export default Blog